console.log("heya :D")

var n1=2;
var n2=3;
var sum=n1+n2;
console.log("el resultado de la suma es:"+sum);

var a=2;
var b=2;
var mul=a+b;
console.log("el resultado de la multiplicacion es:"+mul);

var Rcuadrada= Math.sqrt(1244);
console.log(Rcuadrada)
x= Math.round(Rcuadrada)
console.log(x)
//1 a 500.000
var c=500;
var j=2
var numerosPrimos = [];

for (; j < c; j++) {

  if (primo(j)) {
    numerosPrimos.push(j);
  }
  
}

console.log(numerosPrimos);

function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;
}
// raiz cuadrada sin funcion